package com.scripts.day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.lib.day4.waitStrategies;

public class ImplicitWait_GoogleSearch {
	
  WebDriver driver;
  waitStrategies wst = new waitStrategies();
  
  @Test(priority=1)
  public void Implicit_Wait_Test() {
	  driver = new ChromeDriver();
	  wst.init(driver);
	  
	  
  }
  
  @Test(priority=2)
  public void launch_google() {
	  driver.get("https://www.google.com");	 
	  wst.Waiting_Implicit(20);
	  driver.findElement(By.name("q")).sendKeys("Test Implicit Wait Check");// exception
  }
  
  @Test(priority=3)
  public void Explicit_OrangeTest() {
	  
	  ////button[@type=\"button\"])[1]
	 wst.Waiting_Explicit();
  }
  
  
  
  
}


package com.lib.day4;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class waitStrategies {
	static WebDriver driver;
	

	
	public void init(WebDriver driver) {
		this.driver = driver;
		
		
	}
	
	public static void Waiting_Implicit(int tm) {		   
	       driver.manage().timeouts()
	       .implicitlyWait(Duration.ofSeconds(tm));
	       }
	
	
	

	public static void Waiting_Explicit() {
		    driver.get("https://www.orangetravels.in/#/");
	        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10)); 
	             
	        wait
	        .until(ExpectedConditions.visibilityOfElementLocated
	        		(By.xpath("(//button[@type='button'])[1]")));
	        driver.findElement(By.xpath("(//button[@type=\"button\"])[1]")).click();
	        
	        //ExpectedConditions.v
	        
	        ExpectedConditions.frameToBeAvailableAndSwitchToIt("")
	          
	}
	
		
	

}
